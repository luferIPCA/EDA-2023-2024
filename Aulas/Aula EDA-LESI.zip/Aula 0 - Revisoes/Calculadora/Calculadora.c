/*****************************************************************//**
 * @file   Calculadora.c
 * @brief  
 * 
 * @author lufer
 * @date   February 2024
 *********************************************************************/

#include "Xiineses/Funcoes.h"
#include <ctype.h>

#pragma comment(lib,"Xiineses/Benfica.lib")

int main() {

	struct Calculo a;

	int x = Soma(2, 3);

	//getche();
	return 0;
}
