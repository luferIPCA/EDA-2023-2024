/*****************************************************************//**
 * @file   Header.h
 * @brief  Descreve....
 * 
 * @author lufer
 * @date   February 2024
 *********************************************************************/
#pragma once

#define N 20

typedef struct Pessoa {
	char nome[N];
	int idade;
}Pessoa;

void Escreve(Pessoa p);





