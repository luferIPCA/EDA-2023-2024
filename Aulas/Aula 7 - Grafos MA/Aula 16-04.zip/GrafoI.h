#pragma once
/*
* Grafos com Matrizes de Adjac�ncias
* Assinatura de fun��es
* 
* =========================================================
* a) Grafo orientado, n�o pesado
* b) Grafo orientado e pesado
* c) Grafo n�o orientado e pesado
* d) Grafo n�o orientado e n�o pesado
*=========================================================
*/
#include <stdbool.h>
#define NUMVERTICES 20
#define N 20


#pragma region Matriz

#pragma region Estatico

// Matriz de Adjac�ncias
// h1: estrutura est�tica
// 
// Grafo
//int adj[NUMVERTICES][NUMVERTICES];

//int vertices[NUMVERTICES];

bool CreateMA(int m[][NUMVERTICES], int totVertices);
bool AddEdge(int m[][NUMVERTICES], int v1, int v2, int w);	//grafo pesado
//bool addEdge(int m[][NUMVERTICES], int v1, int v2);		//grafo n�o pesado				//grafo n�o pesado
bool ExistEdge(int m[][NUMVERTICES], int v1, int v2);
bool GetEdgeWeight(int m[][NUMVERTICES], int v1, int v2, int*w);


#pragma endregion

#pragma endregion

