
#include "GrafoI.h"
#include <malloc.h>

#pragma region h1

/*
* Inicializa a Matriz de Adj
*/
bool CreateMA(int m[][NUMVERTICES], int totVertices){
	if (totVertices <= 0 || totVertices > NUMVERTICES) 
		return false;
	for (int i = 0; i < totVertices; i++)
		for (int j = 0; j < totVertices; j++)
			m[i][j] = -1;
	return true;
}


/*
* n�o orientado
* pesado
*/
bool AddEdge(int m[][NUMVERTICES], int v1, int v2, int w) {
	//Testes...return false
	m[v1][v2] = w;
	m[v2][v1] = w;
	return true;
}


bool ExistEdge(int m[][NUMVERTICES], int v1, int v2) {
		//testes

	//if (m[v1][v2] != -1) return true;
	//return false;

	return(m[v1][v2] != -1);
}

bool GetEdgeWeight(int m[][NUMVERTICES], int v1, int v2, int *w) {
	//testes
	if (m[v1][v2] != -1) {
	//if(ExistEdge(m,v1,v2)){
		*w = m[v1][v2];
		return true;
	}
	else {
		*w = -1;
		return false;
	}

}
#pragma endregion


