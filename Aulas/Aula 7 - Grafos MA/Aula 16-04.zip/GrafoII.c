/*
* Lidar com Matrizes de dimens�o dinamica
* 
//h1
//int **array = malloc(nrows * sizeof(int *));
//array[i]=(int*)malloc(ncols * sizeof(int));
//usar
//array[i][j]=0;

// h2
//g->adj = (int**)malloc(sizeof(int) * v * v);
//usar
//g->adj[i*v+j] = 0;
*/
#include "GrafoII.h"
#include <malloc.h>

#pragma region h1
/*
* Cria grafo e incializa Matriz de Adjacencias
*/
GraphII* CriaGraphII() {
	GraphII* aux = (GraphII*)malloc(sizeof(GraphII));
	if (aux != NULL) {
		aux->adj = NULL;
		aux->v = 0;
	}
	return aux;
}

GraphII* CriaMAGraphII(GraphII* g, int v) {
	//Testes
	if (g == NULL) return g;

	//int* a = (int*)malloc(sizeof(int)*v);

	g->adj = (int**)malloc(sizeof(int*) * v);
	if (g->adj == NULL) return NULL;

	for (int i = 0; i < v; i++) {
		g->adj[i] = (int*)malloc(sizeof(int)*v);
		if (g->adj[i] == NULL) return NULL;
	}
	//inicializa
	for (int i = 0; i < v; i++)
		for (int j = 0; j <v; j++)
		{
			g->adj[i][j] = 0;
		}
	g->v = v;
	return g;
}

GraphII* AddEdgeII(GraphII* g, int v1, int v2) {
	//testes
	g->adj[v1][v2] = 1;
	g->adj[v2][v1] = 1;
	return g;
}

void ShowMA(GraphII* g) {
	//testes
	for (int i = 0; i < g->v; i++) {
		for (int j = 0; j < g->v; j++) {
			printf("[%d] ", g->adj[i][j]);
		}
		printf("\n");
	}
}
#pragma endregion

#pragma region h2

GraphII* CriaMAGraphIIh2(GraphII* g, int v) {
	if (g == NULL) return g;

	g->adj = (int**)malloc(sizeof(int) * v * v);
	if (g->adj != NULL) {
		for (int i = 0; i < v; i++)
			for (int j = 0; j < v; j++)
			{
				g->adj[i * v + j] = 0;
			}
	}
	g->v = v;
	return g;
}

GraphII* AddEdgeIIh2(GraphII* g, int v1, int v2, int numV) {
	g->adj[v1 * numV + v2]= 1;
	g->adj[v2 * numV + v1] = 1;
	return g;
}

void ShowMAh2(GraphII* g) {
	//testes
	for (int i = 0; i < g->v; i++) {
		for (int j = 0; j < g->v; j++) {
			printf("[%d] ", g->adj[i*g->v+j]);
		}
		printf("\n");
	}
}


#pragma endregion

