/*
* Grafos - MA
* ESI
* lufer
*/


#include "GrafoI.h"
#include "GrafoII.h"

#include "DadosAula.h"

void Show(GraphII *g) {

	for (int i = 0; i < g->v; i++) {
		for (int j = 0; j < g->v; j++)
			printf("%d", g->adj[i][j]);
		printf("\n");
	}
}

int main() {

#pragma region ESIN

#pragma region Graph - ESIN - h1

	//matriz de adjacencias
	int adj[NUMVERTICES][NUMVERTICES];

	bool aux = CreateMA(adj, 14);
	if (aux == true)
		printf("ok\n");

	aux=AddEdge(adj, 4, 7,5);
	//if (aux)...

	int peso;
	aux = GetEdgeWeight(adj, 4, 7, &peso);
	if (aux == true)
		printf("Dist=%d\n", peso);
	else
		printf("Nao pode ir por ai...");

#pragma endregion

#pragma region GraphII - ESIN

	printf("\nsizeof Graph2=%d\n", sizeof(GraphII));
	GraphII* g1 = CriaGraphII();
	g1= CriaMAGraphII(g1, 3);
	g1 = AddEdgeII(g1, 1, 2);
	g1 = AddEdgeII(g1, 0, 1);
	ShowMA(g1);
	printf("\n");

	//h2
	GraphII* g2 = CriaGraphII();
	g2 = CriaMAGraphIIh2(g2, 3);
	g2 = AddEdgeIIh2(g2, 1, 2, 3);
	ShowMAh2(g2);

#pragma endregion

#pragma endregion

#pragma region H1 - ESI

	Grafo* auxH1 = CriaGrafoH1(10);
	if (auxH1 == NULL)
		printf("ERRO");

	V v1 = { "v1" };
	bool ba = InsereV(auxH1, v1);

	ba = InsereAresta(auxH1, 1, 2, 20);

#pragma endregion

	GraphII* g4 = CriaGraphII();
	g4 = CriaMAGraphII(g4, 20);
	Show(g4);

}